from nebula_ps1.validator import main
raise SystemExit(main())
